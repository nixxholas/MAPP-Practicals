package mapp.com.sg.androidactivity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by nixho on 18-Oct-16.
 */

public class About extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);
    }
}
