package mapp.com.sg.mymobileapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by nixho on 18-Oct-16.
 */

public class PhotoAlbum extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_album);
    }
}
